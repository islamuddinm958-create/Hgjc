package com.example.ivacslotassistant
import android.app.*
import android.content.*
import android.os.Build

class ReminderReceiver: BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = "slot"
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(channel,"IVAC Slot Reminder",NotificationManager.IMPORTANCE_HIGH))
        val n = Notification.Builder(c, channel).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("IVAC Slot Assistant").setContentText("স্লট চেক করার সময় হয়েছে। অফিসিয়াল সাইট খুলে নিজে booking করুন।")
            .setAutoCancel(true).build()
        nm.notify(1001,n)
    }
}
