package com.example.ivacslotassistant

import android.app.*
import android.os.*
import android.content.*
import android.net.Uri
import android.provider.Settings
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var time: EditText
    private lateinit var appId: EditText
    private lateinit var center: EditText
    private val prefs by lazy { getSharedPreferences("ivac", MODE_PRIVATE) }
    private val url = "https://indianvisa-bangladesh.nic.in/"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,32,32,32) }
        val title = TextView(this).apply { text = "IVAC Slot Assistant"; textSize = 26f; setPadding(0,0,0,20) }
        layout.addView(title)
        layout.addView(TextView(this).apply { text = "নিজে বৈধভাবে স্লট নেওয়ার জন্য সহায়ক টুল" })
        appId = EditText(this).apply { hint = "Application ID" }
        center = EditText(this).apply { hint = "IVAC Centre (ঐচ্ছিক)" }
        time = EditText(this).apply { hint = "Reminder time: HH:mm (24-hour)" }
        layout.addView(appId); layout.addView(center); layout.addView(time)

        val save = Button(this).apply { text = "তথ্য সংরক্ষণ" }
        val open = Button(this).apply { text = "অফিসিয়াল সাইট খুলুন" }
        val reminder = Button(this).apply { text = "Reminder সেট করুন" }
        val copy = Button(this).apply { text = "Application ID কপি করুন" }
        layout.addView(save); layout.addView(open); layout.addView(reminder); layout.addView(copy)

        appId.setText(prefs.getString("id",""))
        center.setText(prefs.getString("center",""))
        time.setText(prefs.getString("time","09:00"))

        save.setOnClickListener {
            prefs.edit().putString("id",appId.text.toString()).putString("center",center.text.toString()).putString("time",time.text.toString()).apply()
            Toast.makeText(this,"তথ্য সংরক্ষণ হয়েছে",Toast.LENGTH_SHORT).show()
        }
        open.setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        copy.setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Application ID", appId.text.toString()))
            Toast.makeText(this,"Application ID কপি হয়েছে",Toast.LENGTH_SHORT).show()
        }
        reminder.setOnClickListener { scheduleReminder() }
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun scheduleReminder() {
        val parts = time.text.toString().trim().split(":")
        if (parts.size != 2) { Toast.makeText(this,"HH:mm ফরম্যাট দিন",Toast.LENGTH_SHORT).show(); return }
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, parts[0].toIntOrNull() ?: 9)
            set(Calendar.MINUTE, parts[1].toIntOrNull() ?: 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND,0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR,1)
        }
        val intent = Intent(this, ReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(this, 10, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (getSystemService(ALARM_SERVICE) as AlarmManager).setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        Toast.makeText(this,"Reminder সেট হয়েছে: ${time.text}",Toast.LENGTH_SHORT).show()
    }
}
